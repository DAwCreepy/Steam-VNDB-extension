// Background script (required for manifest v3)
chrome.runtime.onInstalled.addListener(() => {
  // Set default settings
  chrome.storage.sync.set({
    showContentTags: true,
    showSexualTags: true,
    showTechnicalTags: false,
    showMinorSpoilers: false,
    showMajorSpoilers: false
  });
});