(async function () {
  const titleElement = document.querySelector('.apphub_AppName');
  if (!titleElement) return;

  // Get user settings
  const settings = await new Promise(resolve => {
    chrome.storage.sync.get([
      'vndbApiKey',
      'showContentTags',
      'showSexualTags',
      'showTechnicalTags',
      'showMinorSpoilers',
      'showMajorSpoilers'
    ], resolve);
  });

  if (!settings.vndbApiKey) {
    console.log('VNDB API key not set. Please configure the extension.');
    return;
  }

  const title = titleElement.textContent.trim();

  try {
    const response = await fetch("https://api.vndb.org/kana/vn", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `token ${settings.vndbApiKey}`
      },
      body: JSON.stringify({
        filters: ["search", "=", title],
        fields: "title, rating, tags.name, tags.category, tags.spoiler",
        results: 1
      })
    });

    const data = await response.json();
    if (!data.results || data.results.length === 0) return;

    const vn = data.results[0];
    const averageScore = vn.rating?.toFixed(2) || "N/A";
    
    // Filter tags based on user settings and apply spoiler styling
    const filterTags = (tags) => {
      return tags.filter(tag => {
        if (tag.spoiler === 1 && !settings.showMinorSpoilers) return false;
        if (tag.spoiler === 2 && !settings.showMajorSpoilers) return false;
        return true;
      }).map(tag => {
        if (tag.spoiler === 1) {
          return `<span style="color: #FFD700;">${tag.name}</span>`; // Yellow for minor spoilers
        } else if (tag.spoiler === 2) {
          return `<span style="color: #FF6347;">${tag.name}</span>`; // Red for major spoilers
        }
        return tag.name;
      });
    };

    const contentTags = settings.showContentTags ? 
      filterTags((vn.tags || []).filter(tag => tag.category === "cont")) : [];
    
    const sexualTags = settings.showSexualTags ? 
      filterTags((vn.tags || []).filter(tag => tag.category === "ero")) : [];

    const technicalTags = settings.showTechnicalTags ? 
      filterTags((vn.tags || []).filter(tag => tag.category === "tech")) : [];

    const infoBox = document.createElement("div");
    infoBox.style.border = "1px solid #2a475e";
    infoBox.style.padding = "10px";
    infoBox.style.marginTop = "10px";
    infoBox.style.backgroundColor = "#1b2838";
    infoBox.style.color = "white";
    infoBox.style.borderRadius = "3px";
    
    let html = `
      <h4 style="margin:0 0 5px;color:#67c1f5;">VNDB Info</h4>
      <strong>Score:</strong> ${averageScore}<br/>
    `;

    if (settings.showContentTags) {
      html += `
        <div style="margin-top:8px;">
          <strong>Content Tags:</strong><br/>
          ${contentTags.length > 0 ? contentTags.join(", ") : "No content tags"}
        </div>
      `;
    }

    if (settings.showSexualTags) {
      html += `
        <div style="margin-top:8px;">
          <strong>Sexual Content Tags:</strong><br/>
          ${sexualTags.length > 0 ? sexualTags.join(", ") : "No sexual content tags"}
        </div>
      `;
    }

    if (settings.showTechnicalTags) {
      html += `
        <div style="margin-top:8px;">
          <strong>Technical Tags:</strong><br/>
          ${technicalTags.length > 0 ? technicalTags.join(", ") : "No technical tags"}
        </div>
      `;
    }

    infoBox.innerHTML = html;

    const insertTarget = document.querySelector(".user_reviews");
    if (insertTarget) {
      insertTarget.parentElement.insertBefore(infoBox, insertTarget);
    }
  } catch (error) {
    console.error("VNDB Info Error:", error);
  }
})();