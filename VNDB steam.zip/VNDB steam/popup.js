document.addEventListener('DOMContentLoaded', function() {
  const saveBtn = document.getElementById('saveBtn');
  const statusEl = document.getElementById('status');
  
  // Load saved settings
  chrome.storage.sync.get([
    'vndbApiKey',
    'showContentTags',
    'showSexualTags',
    'showTechnicalTags',
    'showMinorSpoilers',
    'showMajorSpoilers'
  ], function(data) {
    document.getElementById('apiKey').value = data.vndbApiKey || '';
    document.getElementById('showContentTags').checked = data.showContentTags !== false;
    document.getElementById('showSexualTags').checked = data.showSexualTags !== false;
    document.getElementById('showTechnicalTags').checked = data.showTechnicalTags || false;
    document.getElementById('showMinorSpoilers').checked = data.showMinorSpoilers || false;
    document.getElementById('showMajorSpoilers').checked = data.showMajorSpoilers || false;
  });
  
  saveBtn.addEventListener('click', function() {
    const settings = {
      vndbApiKey: document.getElementById('apiKey').value,
      showContentTags: document.getElementById('showContentTags').checked,
      showSexualTags: document.getElementById('showSexualTags').checked,
      showTechnicalTags: document.getElementById('showTechnicalTags').checked,
      showMinorSpoilers: document.getElementById('showMinorSpoilers').checked,
      showMajorSpoilers: document.getElementById('showMajorSpoilers').checked
    };
    
    chrome.storage.sync.set(settings, function() {
      statusEl.textContent = 'Settings saved!';
      setTimeout(() => statusEl.textContent = '', 2000);
      
      // Refresh any active Steam page to apply changes
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0] && tabs[0].url.includes('store.steampowered.com/app/')) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
    });
  });
});